plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    kotlin("kapt") // Aplica el plugin kotlin-kapt
}

android {
    namespace = "com.tuempresa.inventario"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tuempresa.inventario"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        room {
            schemaLocation.set("schemas")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.room.common)
    implementation(libs.androidx.room.common.jvm)
    testImplementation(libs.junit)
    testImplementation ("junit:junit:4.13.2")
    testImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation("com.google.code.gson:gson:2.10.1") // o la versión más reciente
    implementation("androidx.recyclerview:recyclerview:1.3.2") // o la versión más reciente
    implementation("org.apache.poi:poi:5.2.5") // o la versión más reciente
    implementation("org.apache.poi:poi-ooxml:5.2.5") // o la versión más reciente
    implementation("androidx.room:room-runtime:2.5.0") // Reemplaza con la versión más reciente
    kapt("androidx.room:room-compiler:2.5.0") // Si usas Kotlin
}