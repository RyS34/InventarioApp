package com.tuempresa.inventario

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tuempresa.inventario.model.StockItem

class EntradaProductos : AppCompatActivity() {
    private lateinit var stockAdapter: EntradaProductosAdapter
    private lateinit var stockList: MutableList<StockItem>
    private lateinit var etCodigo: EditText
    private lateinit var etDescripcion: EditText
    private lateinit var etLote: EditText
    private lateinit var etUsuario: EditText
    private lateinit var etCantidad: EditText
    private lateinit var etFechaIngreso: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_entrada_productos)

        etCodigo = findViewById(R.id.etCodigo)
        etDescripcion = findViewById(R.id.etDescripcion)
        etLote = findViewById(R.id.etLote)
        etUsuario = findViewById(R.id.etUsuario)
        etCantidad = findViewById(R.id.etCantidad)
        etFechaIngreso = findViewById(R.id.etFechaIngreso)

        // Establecer el foco en el campo de código
        etUsuario.requestFocus()

        // Cargar los datos del stock
        stockList = cargarStockItems()

        // Configurar el RecyclerView
        val rvProductos = findViewById<RecyclerView>(R.id.rvProductos)
        rvProductos.layoutManager = LinearLayoutManager(this)

        // Crear y configurar el adaptador
        stockAdapter = EntradaProductosAdapter(stockList) { selectedItem ->
            // Manejar la selección de un elemento
            etCodigo.setText(selectedItem.codigo)
            etDescripcion.setText(selectedItem.descripcion)
            etLote.setText(selectedItem.lote)
            etFechaIngreso.setText(selectedItem.fechaIngreso)

            // Deshabilitar campos
            etCodigo.isEnabled = false
            etDescripcion.isEnabled = false
            etLote.isEnabled = false
            etFechaIngreso.isEnabled = false
        }
        rvProductos.adapter = stockAdapter

        // Configurar el botón "Ingresar"
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)
        btnIngresar.setOnClickListener {
            val codigo = etCodigo.text.toString()
            val descripcion = etDescripcion.text.toString()
            val lote = etLote.text.toString()
            val usuario = etUsuario.text.toString()
            val cantidad = etCantidad.text.toString().toIntOrNull() ?: 0
            val fechaIngreso = etFechaIngreso.text.toString()

            if (codigo.isEmpty() || descripcion.isEmpty() || lote.isEmpty() || usuario.isEmpty() || cantidad == 0 || fechaIngreso.isEmpty()) {
                Toast.makeText(this, "Es necesario llenar todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val nextId = getNextId()

            val nuevoStockItem = StockItem(

                codigo = codigo,
                descripcion = descripcion,
                lote = lote,
                cantidad = cantidad,
                fechaIngreso = fechaIngreso,
                usuario = usuario
            )
            actualizarStock(nuevoStockItem)

            Toast.makeText(this, "Producto ingresado al stock", Toast.LENGTH_SHORT).show()

            etCodigo.text.clear()
            etDescripcion.text.clear()
            etLote.text.clear()
            etCantidad.text.clear()
            etFechaIngreso.text.clear()
            etUsuario.text.clear()

            saveNextId(nextId + 1)
        }

        val btnSalir = findViewById<Button>(R.id.btnSalir)
        btnSalir.setOnClickListener {
            finish()
        }
        // Establecer el foco en el campo de cantidad
        etUsuario.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                etCantidad.requestFocus()
            }
        }
    }

    private fun actualizarStock(nuevoStockItem: StockItem) {
        Log.d("EntradaProductos", "Nuevo código: ${nuevoStockItem.codigo}")
        Log.d("EntradaProductos", "Nuevo item: $nuevoStockItem")
        val existingItemIndex = stockList.indexOfFirst { it.codigo == nuevoStockItem.codigo }
        if (existingItemIndex != -1) {
            Log.d("EntradaProductos", "Código existente encontrado en el índice: $existingItemIndex")
            val existingItem = stockList[existingItemIndex]
            val cantidadActualizada = existingItem.cantidad + nuevoStockItem.cantidad
            val stockItemActualizado = existingItem.copy(cantidad = cantidadActualizada)
            stockList[existingItemIndex] = stockItemActualizado
        } else {
            Log.d("EntradaProductos", "No se encontró el código existente")
            stockList.add(nuevoStockItem)
        }
        guardarStockItems(stockList)
        stockAdapter.notifyDataSetChanged()
    }

    private fun cargarStockItems(): MutableList<StockItem> {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        val stockListJson = sharedPreferences.getString("stockList", null)
        Log.d("EntradaProductos", "stockListJson: $stockListJson")

        // Verificar si stockListJson es nulo
        if (stockListJson != null) {
            val gson = Gson()
            val type = object : TypeToken<MutableList<StockItem>>() {}.type
            val stockList = try {
                gson.fromJson<MutableList<StockItem>>(stockListJson, type)
            } catch (e: Exception) {
                Log.e("EntradaProductos", "Error al convertir JSON: ${e.message}")
                return mutableListOf()
            }
            Log.d("EntradaProductos", "StockList: $stockList")
            return stockList
        }

        Log.d("EntradaProductos", "StockList: Lista vacía")
        return mutableListOf()
    }


    private fun guardarStockItems(stockList: MutableList<StockItem>) {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val stockListJson = gson.toJson(stockList)
        editor.putString("stockList", stockListJson)
        editor.apply()
    }


    private fun getNextId(): Int {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        return sharedPreferences.getInt("nextId", 1)
    }

    private fun saveNextId(nextId: Int) {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("nextId", nextId)
        editor.apply()
    }
}