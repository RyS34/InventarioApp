package com.tuempresa.inventario

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductosAdapter(private val productosList: MutableList<Producto>) : RecyclerView.Adapter<ProductosAdapter.ProductoViewHolder>() {

    var selectedPosition = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_producto_salida, parent, false)
        return ProductoViewHolder(itemView)
    }

    // Método para actualizar la lista de productos
    @SuppressLint("SetTextI18n", "NotifyDataSetChanged")
    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        val producto = productosList[position]
        holder.tvCodigo.text = producto.codigo
        holder.tvDescripcion.text = producto.descripcion
        holder.tvLote.text = producto.lote
        holder.tvCantidad.text = producto.cantidad.toString()
        holder.tvUsuario.text = producto.usuario

        // Establecer el color de fondo del elemento seleccionado
        holder.itemView.setOnClickListener {
            selectedPosition = holder.getBindingAdapterPosition()
            notifyDataSetChanged()
        }

        // Establecer el color de fondo del elemento seleccionado
        if (selectedPosition == position) {
            holder.itemView.setBackgroundResource(android.R.color.darker_gray)
        } else {
            holder.itemView.setBackgroundResource(android.R.color.transparent)
        }
    }

    override fun getItemCount() = productosList.size

    // Método para actualizar la lista de productos
    class ProductoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCodigo: TextView = itemView.findViewById(R.id.tvCodigo)
        val tvDescripcion: TextView = itemView.findViewById(R.id.tvDescripcion)
        val tvLote: TextView = itemView.findViewById(R.id.tvLote)
        val tvCantidad: TextView = itemView.findViewById(R.id.tvCantidad)
        val tvUsuario: TextView = itemView.findViewById(R.id.tvUsuario)
    }
}