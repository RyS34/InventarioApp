package com.tuempresa.inventario

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tuempresa.inventario.model.StockItem

class EntradaProductosAdapter(
    private val stockList: List<StockItem>,
    private val itemClickListener: (StockItem) -> Unit
) : RecyclerView.Adapter<EntradaProductosAdapter.EntradaProductosViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION

    // Definir el ViewHolder
    class EntradaProductosViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCodigo: TextView = itemView.findViewById(R.id.tvCodigo)
        val tvDescripcion: TextView = itemView.findViewById(R.id.tvDescripcion)
        val tvLote: TextView = itemView.findViewById(R.id.tvLote)
        val tvCantidad: TextView = itemView.findViewById(R.id.tvCantidad)
        val tvFechaIngreso: TextView = itemView.findViewById(R.id.tvFechaIngreso)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntradaProductosViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_stock_entrada, parent, false)
        return EntradaProductosViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: EntradaProductosViewHolder, position: Int) {
        val currentItem = stockList[position]

        // Configurar los datos en los TextViews
        holder.tvCodigo.text = currentItem.descripcion // <-- Cambiar el orden aquí
        holder.tvDescripcion.text = currentItem.codigo
        holder.tvLote.text = currentItem.lote ?: ""
        holder.tvCantidad.text = currentItem.cantidad.toString()
        holder.tvFechaIngreso.text = currentItem.fechaIngreso ?: ""

        // Establecer el color de fondo según la selección
        if (position == selectedPosition) {
            holder.itemView.setBackgroundColor(Color.LTGRAY)
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT)
        }

        // Configurar el escucha de clics en el elemento
        holder.itemView.setOnClickListener {
            val previousSelectedPosition = selectedPosition
            selectedPosition = if (position == selectedPosition) {
                RecyclerView.NO_POSITION
            } else {
                position
            }
            if (previousSelectedPosition != RecyclerView.NO_POSITION) {
                notifyItemChanged(previousSelectedPosition)
            }
            if (selectedPosition != RecyclerView.NO_POSITION) {
                notifyItemChanged(selectedPosition)
            }

            itemClickListener(currentItem)
        }
    }

    override fun getItemCount() = stockList.size
}