package com.tuempresa.inventario

import android.util.Log
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tuempresa.inventario.model.StockItem
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.InputStream

class StockGeneralActivity : AppCompatActivity() {

    private lateinit var recyclerViewStock: RecyclerView
    private lateinit var stockAdapter: StockAdapter
    private lateinit var buttonSalir: Button
    private lateinit var buttonImportar: Button
    private lateinit var openFileLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock_general)

        recyclerViewStock = findViewById(R.id.recyclerViewStock)
        recyclerViewStock.layoutManager = LinearLayoutManager(this)

        buttonSalir = findViewById(R.id.buttonSalir)
        buttonSalir.setOnClickListener {
            finish()
        }

        buttonImportar = findViewById(R.id.buttonImportar)
        buttonImportar.setOnClickListener {
            openFileLauncher.launch(createOpenFileIntent())
        }

        openFileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri: Uri? = result.data?.data
                if (uri != null) {
                    leerArchivoExcel(uri)
                }
            }
        }
    }

    // Actualizar la lista cuando se reanuda la actividad
    override fun onResume() {
        super.onResume()
        val stockList = cargarStockItems()
        stockAdapter = StockAdapter(stockList) { stockItem ->
            Toast.makeText(this, stockItem.codigo, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.descripcion, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.lote, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.cantidad.toString(), Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.fechaIngreso, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.fechaVencimiento, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.ordenCompra, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.ubicacion, Toast.LENGTH_SHORT).show()
            Toast.makeText(this, stockItem.ubicacionDetallada, Toast.LENGTH_SHORT).show()


        }
        recyclerViewStock.adapter = stockAdapter
    }

    private fun cargarStockItems(): MutableList<StockItem> {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        val stockListJson = sharedPreferences.getString("stockList", null)
        val gson = Gson()
        val type = object : TypeToken<MutableList<StockItem>>() {}.type
        return gson.fromJson(stockListJson, type) ?: mutableListOf()
    }

    private fun createOpenFileIntent(): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
    }

    fun leerArchivoExcel(uri: Uri) = try {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        if (inputStream == null) {
        } else {
            val workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0)

            // Obtener los datos del archivo Excel
            val stockList = cargarStockItems()
            // Limpiar la lista existente
            for (row in sheet) {
                val id = row.getCell(1)?.stringCellValue ?: ""
                val codigo = row.getCell(2)?.stringCellValue ?: ""
                val descripcion = row.getCell(3)?.stringCellValue ?: ""
                val lote = row.getCell(4)?.stringCellValue ?: ""
                var cantidad = 0

                try {
                    Log.d("ExcelDebug", "Valor de la celda: ${row.getCell(5)?.numericCellValue}")
                    cantidad = row.getCell(5)?.numericCellValue?.toInt() ?: 0
                } catch (e: IllegalStateException) {
                    e.printStackTrace()
                    runOnUiThread {
                        Toast.makeText(this, "Error en la fila ${row.rowNum + 1}: La celda de cantidad contiene texto.", Toast.LENGTH_LONG).show()
                    }
                    continue
                }

                // Resto del código para procesar la fila
                val fechaIngreso = ""
                val fechaVencimiento = row.getCell(6)?.stringCellValue ?: ""
                val ordenCompra = ""
                val ubicacion = row.getCell(8)?.stringCellValue ?: ""
                val ubicacionDetallada = row.getCell(9)?.stringCellValue ?: ""

                // Crear un nuevo objeto StockItem y agregarlo a la lista
                val nuevoStockItem = StockItem(

                    codigo,
                    descripcion,
                    lote,
                    cantidad,
                    fechaIngreso,
                    fechaVencimiento,
                    ordenCompra,
                    ubicacion,
                    ubicacionDetallada,

                )
                stockList.add(nuevoStockItem)
            }

            // Guardar la lista actualizada en SharedPreferences
            guardarStockItems(stockList)

            workbook.close()
            inputStream.close()

            runOnUiThread {
                onResume()
                Toast.makeText(this, "Datos importados correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        runOnUiThread {
            Toast.makeText(this, "Error al leer el archivo Excel: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun guardarStockItems(stockList: MutableList<StockItem>) {
        val sharedPreferences = getSharedPreferences("StockData", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val stockListJson = gson.toJson(stockList)
        editor.putString("stockList", stockListJson)
        editor.apply()
    }
}