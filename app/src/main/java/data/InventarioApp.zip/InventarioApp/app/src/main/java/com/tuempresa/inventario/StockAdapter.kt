// StockAdapter.kt
package com.tuempresa.inventario

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tuempresa.inventario.model.StockItem

class StockAdapter(
    private val stockList: List<StockItem>,
    private val itemClickListener: (StockItem) -> Unit
) : RecyclerView.Adapter<StockAdapter.StockViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION

    class StockViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCodigo: TextView = itemView.findViewById(R.id.tvCodigo)
        val tvDescripcion: TextView = itemView.findViewById(R.id.tvDescripcion)
        val tvLote: TextView = itemView.findViewById(R.id.tvLote)
        val tvCantidad: TextView = itemView.findViewById(R.id.tvCantidad)
        val tvFechaVencimiento: TextView = itemView.findViewById(R.id.tvFechaVencimiento)
        val tvUbicacion: TextView = itemView.findViewById(R.id.tvUbicacion)
        val tvUbicacionDetallada: TextView = itemView.findViewById(R.id.tvUbicacionDetallada)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StockViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_stock, parent, false)
        return StockViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: StockViewHolder, position: Int) {
        val currentItem = stockList[position]

        holder.tvCodigo.text = currentItem.codigo
        holder.tvDescripcion.text = currentItem.descripcion
        holder.tvLote.text = currentItem.lote ?: ""
        holder.tvCantidad.text = currentItem.cantidad.toString()
        holder.tvFechaVencimiento.text = currentItem.fechaVencimiento
        holder.tvUbicacion.text = currentItem.ubicacion
        holder.tvUbicacionDetallada.text = currentItem.ubicacionDetallada

        if (position == selectedPosition) {
            holder.itemView.setBackgroundColor(Color.LTGRAY)
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT)
        }

        holder.itemView.setOnClickListener {
            val previousSelectedPosition = selectedPosition
            selectedPosition = if (position == selectedPosition) {
                RecyclerView.NO_POSITION
            } else {
                position
            }
            if (previousSelectedPosition != RecyclerView.NO_POSITION) {
                notifyItemChanged(previousSelectedPosition)
            }
            if (selectedPosition != RecyclerView.NO_POSITION) {
                notifyItemChanged(selectedPosition)
            }
            itemClickListener(currentItem)
        }
    }

    override fun getItemCount() = stockList.size
}