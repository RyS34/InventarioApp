package com.tuempresa.inventario.model

data class StockItem(//modelo de la tabla

    val codigo: String,
    val descripcion: String,
    val lote: String,
    val cantidad: Int,//cantidad actual
    val fechaIngreso: String,
    val fechaVencimiento: String = "",
    val ordenCompra: String = "",
    val ubicacion: String = "",
    val ubicacionDetallada: String = "",

    //nuevos campos
    val usuario: String = ""

)